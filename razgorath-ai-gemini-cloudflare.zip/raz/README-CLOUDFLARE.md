# RAZGORATH AI — Cloudflare Direct Upload + Gemini

This version uses Cloudflare Pages Advanced Mode with `_worker.js`, so the `/api/chat` endpoint is handled without a `functions/` directory.

## Deploy

1. Upload this project using your Cloudflare Pages Direct Upload / drag-and-drop flow.
2. Make sure `_worker.js` is included in the uploaded project.
3. In your Cloudflare project settings, add an environment variable/secret named:

   `GEMINI_API_KEY`

4. Put your Gemini API key in that secret. Never put the key in `index.html` or `assets/*.js`.
5. Redeploy the project.

The frontend already calls:

`POST /api/chat`

The `_worker.js` file handles that route and forwards the request to Gemini, then returns the response in the streaming format expected by the existing frontend.

## Important

Cloudflare's documentation says dashboard drag-and-drop does not compile a `functions/` directory, while `_worker.js` is supported for direct uploads. Advanced Mode requires the `_worker.js` module to forward non-API requests to `env.ASSETS.fetch(request)`.
